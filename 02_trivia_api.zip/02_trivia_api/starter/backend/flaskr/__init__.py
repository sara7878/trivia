import os
from flask import Flask, request, abort, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import random

from models import setup_db, Question, Category

QUESTIONS_PER_PAGE = 10

def create_app(test_config=None):
  app = Flask(__name__)
  setup_db(app)
  

  CORS(app, resources={r'/*': {'origins': '*'}})

  @app.after_request
  def set_headers(response):
      
      response.headers.add('Access-Control-Allow-Headers',
                            'Content-Type, Authorization, true')
      response.headers.add('Access-Control-Allow-Methods',
                            'GET, PATCH, POST, DELETE, OPTIONS')
      return response



  @app.route('/questions')
  def retrieve_questions():
    page = request.args.get('page', 1, type=int)
    start = page*QUESTIONS_PER_PAGE
    end = start - QUESTIONS_PER_PAGE

    my_categories = Category.query.all()    
    my_questions = Question.query.all()
    my_formatted_questions = [my_question.format() for my_question in my_questions]
    my_formatted_categories = {my_category.id: my_category.type for my_category in my_categories}
    len_questions=len(my_formatted_questions[end :start])
    if len_questions > 0:
      return jsonify({
        'success': True,
        'questions': my_formatted_questions[end :start],
        'categories': my_formatted_categories,        
        'total_questions': len(my_formatted_questions),
        'current_category': None
    })
    else:
      abort(404)

  @app.route('/categories' , methods=['GET'])
  def retrieve_categories():
    try:
      my_categories = Category.query.order_by(Category.id).all()
      len_my_categories=len(my_categories)
      return jsonify({
        'success': True,    
        'total_categories': len_my_categories,
        'categories': {category.id: category.type for category in my_categories}
       
      })
    except:
      abort(404)
  
  @app.route('/questions/<int:question_id>' , methods=['DELETE'] )
  def delete_question(question_id):      
    my_question = Question.query.get(question_id)
      
    if my_question == None:
      abort(404)
      
    else:
      my_question.delete()
      return jsonify({
        'success': True,
        'deleted': question_id  
      })


  @app.route('/searchQuestions', methods=['POST'])
  def search_questions():
    body = request.get_json()
    searchTerm = body.get('searchTerm', None)
      
    if searchTerm != None:
      my_questions = Question.query.filter(Question.question.ilike('%' + searchTerm + '%')).all()
      my_formatted_questions = [my_question.format() for my_question in my_questions]

      return jsonify({
          'success': True,          
          'total_questions': len(my_formatted_questions),
          'questions': my_formatted_questions
        })
    else:
      return abort(400)



  @app.route('/questions', methods=["POST"])
  def create_question():
    body = request.get_json()    
    new_difficulty = body.get('difficulty', None)
    new_answer = body.get('answer', None)    
    new_category = body.get('category', None)
    new_question = body.get('question', None)

    if (new_question != None) and (new_category != None) and (new_answer != None) and (new_difficulty != None):
      my_new_question = Question(new_question, new_answer, new_category, new_difficulty)
      my_new_question.insert()  
      return jsonify({
          'success': True,
          'question': my_new_question.format()
        })
    else:      
      abort(400)




  @app.route('/categories/<int:category_id>/questions', methods=['GET'])
  def retrieve_questions_based_on_category(category_id):

    my_category = Category.query.get(category_id)
    my_question = Question.query.filter_by(category=str(category_id)).all()
    len_my_questions=len(my_question)    
    my_questions = list(map(Question.format, my_question))

    if  len_my_questions == 0:
      return jsonify({
          "success": False,
          "message": "not found"
      })
    else:
      return jsonify({
          'success': True,             
          'questions': my_questions,
          'category': Category.format(my_category)
      })
      


  @app.route("/quizzes", methods=['POST'])
  def get_question_for_quiz():
    if request.data:
      previous_questions = request.json.get('previous_questions')
      quiz_category = request.json.get('quiz_category')

      if not quiz_category:
          return abort(400)


      if (int(quiz_category.get('id')) > 0):
        questions = Question.query.filter_by(
                category=str(quiz_category.get('id'))
            ).filter(
                Question.id.notin_(previous_questions)
            ).all()
        

        
      else:        
        questions = Question.query.all()


      length_of_question = len(questions)

      if length_of_question == 0:
        return jsonify({
            "success": False,
            "question": None
        })
      else:
        return jsonify({
              "success": True,
              "question": Question.format(
                  questions[random.randrange(
                      0,
                      length_of_question )]
              )
          })

    return abort(400, 'Quiz data missing from request')


  '''
  @TODO: 
  Create error handlers for all expected errors 
  including 404 and 422. 
  '''
  @app.errorhandler(400)
  def not_found(error):
      return jsonify({
          "success": False,
          "error": 400,
          "message": "Bad Request"
      }),400

  @app.errorhandler(404)
  def not_found(error):
      return jsonify({
          "success": False,
          "error": 404,
          "message": "Resource not found"
      }),404

  @app.errorhandler(422)
  def unprocessable(error):
      return jsonify({
          "success": False,
          "error": 422,
          "message": "Unprocessable"
      }),422

  @app.errorhandler(405)
  def method_not_allowed(error):
      return jsonify({
          "success": False,
          "error": 405,
          "message": "The method is not allowed for the requested URL"
      }),405
      

  
  return app

